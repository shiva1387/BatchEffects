### R code from vignette source 'xcmsInstall.Rnw'

